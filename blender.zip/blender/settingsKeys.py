import bpy
import os
import pathlib
import math
import json
import mathutils
from bpy import context

import numpy as np

from mathutils import Vector

# В папке должны быть только jsons-ы, которые мы будем использовать 
# folder_path = "E:\\coursework\\openpose\\output\\jump\\json\\"
folder_path = "E:\\coursework\\openpose\\output\\final\\json\\"
# Название скелета
# Список костей. Обязательно - в порядке уровней иерархии
armatureName = 'free3dmodel_skeleton' 
bonesList = ["hips",  
           "upper_arm.L", "upper_arm.R",
           "thigh.L", "thigh.R", 
           "neck",
           "forearm.L", "forearm.R", 
           "shin.L", "shin.R", 
           "foot.L", "foot.R"]
# Номера шаров, от начала к концу кости
jsonPointsIndexes = [[8, 1],
                    [5, 6], [2, 3],
                    [12, 13], [9, 10],
                    [1, 0],
                    [6, 7], [3, 4],
                    [13, 14], [10, 11],
                    [14, 20], [11, 23]]
basePoints = []
baseAngles = {}
# Load all json with coordinates. in one file one series of coordinates
frames_fiels = os.listdir(folder_path)

# переменные для определения сдвига всего скелета
# Задается в ручную
bsae_point_armature_begin = [0, 3.02]
bsae_point_armature_end = [0, 4.22]
# Задается в set_angles_each_frame
bsae_point_pic = [0, 0]
armature_height = 0
pic_height = 0

# Данные для предсказания пропусков
# длинна массива
memory_length = 5
memory = []

def file_part(folder_path):
    frame_num = 0
    for file_JSON in frames_fiels:
        print(frame_num)
        with open(folder_path + file_JSON, "r") as read_file:
            data = json.load(read_file)
            coordinates = data["people"][0]["pose_keypoints_2d"]
            
            while 0 in coordinates:
                coordinates[coordinates.index(0)] = memory[-1][coordinates.index(0)]

            if len(memory) == memory_length:
                res = memory[0]
                for i in range (1, memory_length):
                    res = np.add(res, memory[i])
                set_angles_each_frame(np.true_divide(res, memory_length), frame_num)
                memory.pop(0)
                frame_num += 1
            
            if len(memory) < memory_length:
                memory.append(coordinates)

# set dots For 2 coordinates
def set_angles_each_frame(coordinates_get, frame_num):
    global armature_height
    global pic_height
    coordinates = coordinates_get
    if (frame_num % 1 == 0):
        bpy.context.scene.frame_set(frame_num)
        
        # Устанавливаем начальные координаты скелета в блендере и картинке,
        # А так же длинны от начала до конца позвоночника 
        if (bsae_point_pic[0] == 0):
            # Задаем начальные координаты тела на картинке
            bsae_point_pic[0] = coordinates[jsonPointsIndexes[0][0] * 3]
            bsae_point_pic[1] = coordinates[jsonPointsIndexes[0][0] * 3 + 1]

            pic_height = math.sqrt(
                (bsae_point_pic[0] - coordinates[jsonPointsIndexes[0][1] * 3]) ** 2 +
                (bsae_point_pic[1] - coordinates[jsonPointsIndexes[0][1] * 3 + 1]) ** 2)

            armature_height = math.sqrt(
                (bsae_point_armature_end[0] - bsae_point_armature_begin[0]) ** 2 +
                (bsae_point_armature_end[1] - bsae_point_armature_begin[1]) ** 2)
        else:
            del_pic_pos_x = (bsae_point_pic[0] - coordinates[jsonPointsIndexes[0][0] * 3]) / pic_height
            del_pic_pos_y = (bsae_point_pic[1] - coordinates[jsonPointsIndexes[0][0] * 3 + 1]) / pic_height

            del_rig_pos_x = armature_height * del_pic_pos_x
            del_rig_pos_y = armature_height * del_pic_pos_y
            bpy.ops.object.mode_set(mode='POSE')

            pbone = bpy.data.objects[armatureName].pose.bones[bonesList[0]]
            moving = pbone.location
            moving.x = -del_rig_pos_x
            moving.y = del_rig_pos_y
            pbone.keyframe_insert(data_path="location")
        
        if len(memory) == memory_length:
            memory.pop(0)
        memory.append(coordinates)
        # Задпаем углы костей
        for n_bone in range(0, len(jsonPointsIndexes)):                    
            # Номера суставов текущей кости
            n_from = jsonPointsIndexes[n_bone][0]
            n_to =  jsonPointsIndexes[n_bone][1]

            # Значения координат кости
            first_dot_x = coordinates[n_from * 3]
            first_dot_y = coordinates[n_from * 3 + 1]
            second_dot_x = coordinates[n_to * 3]
            second_dot_y = coordinates[n_to * 3 + 1]
            
            reduser = max(first_dot_y, second_dot_y)
            
            new_pos = math.degrees(count_angle(
                [second_dot_x, abs(second_dot_y-reduser)], 
                [first_dot_x, abs(first_dot_y-reduser)],
                [first_dot_x + 1, abs(first_dot_y-reduser)]))
            
            base_pose = math.degrees(baseAngles.get(bonesList[n_bone]))
            res_pose = new_pos - base_pose
            set_bones_angle(bonesList[n_bone], math.radians(res_pose))
    
def set_bones_angle(boneName, angle):
    bpy.ops.object.mode_set(mode='POSE')
    ob = bpy.data.objects[armatureName]
    pbone = ob.pose.bones[boneName]
    
    pbone.rotation_mode = 'XYZ'
    
    pbone.rotation_euler.x = 0
    pbone.rotation_euler.y = 0
    pbone.rotation_euler.z = angle
    
    if pbone.parent != None:
        pbone.rotation_euler.z -= pbone.parent.rotation_euler.z
        if pbone.parent.parent != None:
            pbone.rotation_euler.z -= pbone.parent.parent.rotation_euler.z
    
    pbone.keyframe_insert(data_path="rotation_euler")
    

def set_base_angle():
    obj = bpy.data.objects[armatureName].data
    bpy.ops.object.mode_set(mode='EDIT')
    
    for bone in obj.edit_bones:
        if bone.name in bonesList:
            bone.head.y = 0
            bone.tail.y = 0 
            
            baseAngles.update({bone.name: count_angle([bone.tail[0], bone.tail[2]], 
                                [bone.head[0], bone.head[2]],
                                [bone.head[0] + 1, bone.head[2]])})

# p1, p2, p3 - lists of coordinates
# return angel in degrees 
def count_angle(p1, p2, p3):
    if (p1 == p2 or p2 == p3 or p1 == p3):
        return 0

    if (len(p1) == len(p2) and len(p2) == len(p3)):
        top = bot_p1 = bot_p3 = 0

        for coord in range(len(p1)):
            top += (p1[coord] - p2[coord]) * (p3[coord] - p2[coord])
            bot_p1 += (p1[coord] - p2[coord]) ** 2
            bot_p3 += (p3[coord] - p2[coord]) ** 2
        res = math.acos(
                        top / 
                        (math.sqrt(bot_p1 * bot_p3)))
        if (p1[1] < p3[1]):
            return 2*math.pi-res
        else:
            return res

# p1, p2, p3 - lists of coordinates
# return angel in degrees 
def count_angle(p1, p2, p3):
    if (p1 == p2 or p2 == p3 or p1 == p3):
        return 0

    if (len(p1) == len(p2) and len(p2) == len(p3)):
        top = bot_p1 = bot_p3 = 0

        for coord in range(len(p1)):
            top += (p1[coord] - p2[coord]) * (p3[coord] - p2[coord])
            bot_p1 += (p1[coord] - p2[coord]) ** 2
            bot_p3 += (p3[coord] - p2[coord]) ** 2
        res = math.acos(
                        top / 
                        (math.sqrt(bot_p1 * bot_p3)))
#        print(p1[1], p3[1], math.degrees(res))
        if (p1[1] < p3[1]):
            return 2*math.pi-res
        else:
            return res
print("-------------------")


set_base_angle()
file_part(folder_path)
bpy.ops.object.mode_set(mode='OBJECT')

